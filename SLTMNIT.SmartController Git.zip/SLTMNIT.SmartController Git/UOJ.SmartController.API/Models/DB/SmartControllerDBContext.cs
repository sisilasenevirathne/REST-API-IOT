﻿using Microsoft.EntityFrameworkCore;

namespace UOJ.SmartController.API.Models.DB
{
    public class SmartControllerDBContext : DbContext
    {
        public SmartControllerDBContext(DbContextOptions<SmartControllerDBContext> options) : base(options)
        {

        }

        
        public DbSet<OutdoorParameters> OutdoorParameters { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            
            modelBuilder.Entity<OutdoorParameters>().HasNoKey();
        }
    }
}
