﻿using UOJ.SmartController.API.Models.DB;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace UOJ.SmartController.API.Controllers
{
    [Route("/[controller]")]
    [ApiController]
    public class OutdoorParametersController : ControllerBase
    {
        private readonly SmartControllerDBContext _context;

        public OutdoorParametersController(SmartControllerDBContext context)
        {
            _context = context;
        }

        [HttpPost]
        public async Task<ActionResult<IEnumerable<OutdoorParameters>>> Getoutput2(OutdoorParameters input)
        {
            string storedProc = "exec OutdoorParametersSave " +
                "@DeviceId = " + input.DeviceId + "," +
                "@OutdoorTemperature= '" + input.OutdoorTemperature + "'," +
                "@OutdoorHumidity= '" + input.OutdoorHumidity + "'," +
                "@WifiStrength= '" + input.WifiStrength + "'," +
                "@DeviceDateTime= '" + input.DeviceDateTime + "'";


            return await _context.OutdoorParameters.FromSqlRaw(storedProc).ToListAsync();
        }

        [HttpGet("{deviceId}")]
        public async Task<ActionResult<OutdoorParameters>> GetDeviceParameters(int deviceId)
        {
            string storedProcOutdoorParameterGet = "exec OutdoorParametersGet " +
                "@DeviceId = " + deviceId;

            var OutdoorParameters = await _context.OutdoorParameters.FromSqlRaw(storedProcOutdoorParameterGet).ToListAsync();

            // Check if there's any DeviceParameter in the result
            if (OutdoorParameters != null && OutdoorParameters.Any())
            {
                // Return the first DeviceParameter in the list
                return OutdoorParameters.First();
            }

            // Handle the case when no DeviceParameter is found
            return NotFound();
        }
    }

    
}
