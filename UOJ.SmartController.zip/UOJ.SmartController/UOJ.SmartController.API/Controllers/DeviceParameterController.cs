﻿using UOJ.SmartController.API.Models.DB;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace UOJ.SmartController.API.Controllers
{
    [Route("/[controller]")]
    [ApiController]
    public class DeviceParametersController : ControllerBase
    {
        private readonly SmartControllerDBContext _context;

        public DeviceParametersController(SmartControllerDBContext context)
        {
            _context = context;
        }

        [HttpPost]
        public async Task<ActionResult<IEnumerable<DeviceParameters>>> Getoutput(DeviceParameters input)
        {
            string storedProc2 = "exec DeviceParametersSave " +
                "@DeviceId = " + input.DeviceId + "," +
                "@Mode = '" + input.Mode + "'," +
                "@FanStatus= '" + input.FanStatus + "'," +
                "@AcStatus= '" + input.AcStatus + "'," +
                "@AcMode= '" + input.AcMode + "'," +
                "@AcFan= '" + input.AcFan + "'," +
                "@AcTemperature= " + input.AcTemperature + "," +
                "@IndoorTemperature= " + input.IndoorTemperature + "," +
                "@IndoorHumidity= " + input.IndoorHumidity + "," +
                "@WifiStrength= " + input.WifiStrength + "," +
                "@DeviceDateTime= '" + input.DeviceDateTime + "'," +
                "@Extra= '" + input.Extra + "'";

            return await _context.DeviceParameters.FromSqlRaw(storedProc2).ToListAsync();
        }

        [HttpGet("{deviceId}")]
        public async Task<ActionResult<DeviceParameters>> GetDeviceParameters(int deviceId)
        {
            string storedProc = "exec DeviceParametersGet " +
                "@DeviceId = " + deviceId;

            var deviceParameters = await _context.DeviceParameters.FromSqlRaw(storedProc).ToListAsync();

            // Check if there's any DeviceParameter in the result
            if (deviceParameters != null && deviceParameters.Any())
            {
                // Return the first DeviceParameter in the list
                return deviceParameters.First();
            }

            // Handle the case when no DeviceParameter is found
            return NotFound();
        }


    }
}

//hi