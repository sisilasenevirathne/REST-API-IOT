﻿using System.ComponentModel.DataAnnotations;

namespace UOJ.SmartController.API.Models.DB
{
    public class DeviceParameters
    {
        [Key]
        public int DeviceId { get; set; }
        public string Mode { get; set; }
        public string FanStatus { get; set; }
        public string AcStatus { get; set; }
        public string AcMode { get; set; }
        public string AcFan { get; set; }
        public int AcTemperature { get; set; }
        public int IndoorTemperature { get; set; }
        public int IndoorHumidity { get; set; }
        public int WifiStrength { get; set; }
        public string DeviceDateTime { get; set; }
        public string Extra { get; set; }
    }
}
//hi