﻿using System.ComponentModel.DataAnnotations;

namespace UOJ.SmartController.API.Models.DB
{
    public class OutdoorParameters
    {
        [Key]
        public int DeviceId { get; set; }
        public string OutdoorTemperature { get; set; }
        public string OutdoorHumidity { get; set; }
        public string WifiStrength { get; set; }
        public string DeviceDateTime { get; set; }
        public string Command { get; set; }
    }
}
